USERNAME = 'Vipul1'
PASSWORD = 'Test@123'
COMMENT='It is automated comment'
